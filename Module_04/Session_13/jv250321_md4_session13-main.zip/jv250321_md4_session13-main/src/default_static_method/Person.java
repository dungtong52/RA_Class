package default_static_method;

import java.util.Scanner;

public class Person implements IShop{
    @Override
    public void inputData(Scanner scanner) {

    }
    /*
    * 1. Kế thừa và sử dụng luôn các phương thức default
    * 2. Kế thừa và ghi đè các phuong thức default
    * */
    /*
    * Chỉ có thể kế thừa sử dụng và không thể ghi đè được phương thức static
    * */

}
