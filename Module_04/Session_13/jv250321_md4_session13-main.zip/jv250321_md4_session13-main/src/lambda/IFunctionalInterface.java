package lambda;
@FunctionalInterface
public interface IFunctionalInterface {
    int add(int firstNumber, int secondNumber);
}
