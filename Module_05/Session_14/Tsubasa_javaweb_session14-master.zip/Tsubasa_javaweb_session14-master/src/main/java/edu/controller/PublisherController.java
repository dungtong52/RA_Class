package edu.controller;

import edu.model.entity.Publisher;
import edu.service.PublisherService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/publishers")
public class PublisherController {
    @Autowired
    private PublisherService publisherService;

    @GetMapping
    public String listPublisher(Model model){
        List<Publisher> publishers = publisherService.getPublishers();
        model.addAttribute("publishers",publishers);
        return "publisher/listPublisher";
    }

    @GetMapping("/add")
    public String addPublisher(Model model, HttpSession session){
        //check dang nhap hay chua?

        //... check role cua nguoi dung

        Publisher publisher = new Publisher();
        model.addAttribute("publisher",publisher);
        return "publisher/addPublisher";
    }

    @PostMapping("/add")
    public String doAddPublisher(@ModelAttribute("publisher")Publisher publisher, Model model, RedirectAttributes redirectAttributes){
        Publisher p = publisherService.insertPublisher(publisher);
        if(p!=null){
            redirectAttributes.addFlashAttribute("success","publisher successfully added!");
            return "redirect:/publishers";
        }else{
            model.addAttribute("error","publisher name existed!");
            return "publisher/addPublisher";
        }
    }
}
