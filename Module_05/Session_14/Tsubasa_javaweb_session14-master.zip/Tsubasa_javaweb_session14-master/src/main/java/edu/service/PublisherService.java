package edu.service;

import edu.model.entity.Publisher;

import java.util.List;

public interface PublisherService {
    List<Publisher> getPublishers();
    Publisher insertPublisher(Publisher publisher);
    Publisher updatePublisher(Publisher publisher);
    void  deletePublisher(Integer publisherId);
    Publisher getPublisherById(Integer publisherId);
}
