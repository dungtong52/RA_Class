package edu.service.impl;

import edu.model.entity.Publisher;
import edu.repo.PublisherRepository;
import edu.service.PublisherService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PublisherImpl implements PublisherService {
    @Autowired
    private PublisherRepository publisherRepository;

    @Override
    public List<Publisher> getPublishers() {
        return publisherRepository.findAll();
    }

    @Override
    public Publisher insertPublisher(Publisher publisher) {
        Publisher existed = publisherRepository.findByPublisherName(publisher.getPublisherName());
        if(existed!=null){
            return null;
        }
        return publisherRepository.save(publisher);
    }

    @Override
    public Publisher updatePublisher(Publisher publisher) {
        publisherRepository.findById(publisher.getId()).orElseThrow(()->new EntityNotFoundException("Publisher not found"));
        return publisherRepository.save(publisher);
    }

    @Override
    public void deletePublisher(Integer publisherId) {
        publisherRepository.deleteById(publisherId);
    }

    @Override
    public Publisher getPublisherById(Integer publisherId) {
        return publisherRepository.findById(publisherId).orElseThrow(()->new EntityNotFoundException("Publisher not found"));
    }
}
