package edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiTsuplusSession02Application {

    public static void main(String[] args) {
        SpringApplication.run(ApiTsuplusSession02Application.class, args);
    }

}
