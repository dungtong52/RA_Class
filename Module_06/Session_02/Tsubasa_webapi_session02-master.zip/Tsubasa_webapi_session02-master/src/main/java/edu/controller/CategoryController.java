package edu.controller;

import edu.model.entity.Category;
import edu.model.response.response.ApiDataResponse;
import edu.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/categories")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public ResponseEntity<ApiDataResponse<List<Category>>> getAllCategories() {
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Get list categories successfully!",
                categoryService.getCategories(),
                null,
                HttpStatus.OK
        ), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiDataResponse<Category>> getCategoryById(@PathVariable Long id) {
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Get category " + id + " successfully!",
                categoryService.getCategoryById(id),
                null,
                HttpStatus.OK
        ), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<ApiDataResponse<Category>> createCategory(@RequestBody Category category) {
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Insert category successfully!",
                categoryService.insertCategory(category),
                null,
                HttpStatus.CREATED
        ), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiDataResponse<Category>> updateCategory(@PathVariable Long id, @RequestBody Category category) {
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Update category "+category.getId()+" successfully!",
                categoryService.updateCategory(category),
                null,
                HttpStatus.OK
        ), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiDataResponse<Category>> deleteCategory(@PathVariable Long id) {
        categoryService.deleteCategoryById(id);
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Delete category "+id+" successfully!",
                null,
                null,
                HttpStatus.NO_CONTENT
        ), HttpStatus.NO_CONTENT);
    }
}
