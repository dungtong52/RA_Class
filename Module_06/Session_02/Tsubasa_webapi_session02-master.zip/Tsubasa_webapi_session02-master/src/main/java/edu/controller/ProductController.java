package edu.controller;

import edu.model.entity.Category;
import edu.model.entity.Product;
import edu.model.response.response.ApiDataResponse;
import edu.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/products")
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping
    public ResponseEntity<ApiDataResponse<List<Product>>> getAllProducts() {
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Get list products successfully!",
                productService.getProducts(),
                null,
                HttpStatus.OK
        ), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<ApiDataResponse<Product>> createProduct(@RequestBody Product product) {
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Insert product successfully!",
                productService.insertProduct(product),
                null,
                HttpStatus.CREATED
        ), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiDataResponse<Product>> updateProduct(@PathVariable Long id, @RequestBody Product product) {
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Update roduct "+product.getId()+" successfully!",
                productService.updateProduct(product),
                null,
                HttpStatus.OK
        ), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiDataResponse<Product>> deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Delete product "+id+" successfully!",
                null,
                null,
                HttpStatus.NO_CONTENT
        ), HttpStatus.NO_CONTENT);
    }

    @GetMapping("/by-category/{categoryId}")
    public ResponseEntity<ApiDataResponse<List<Product>>> getProductsByCategory(@PathVariable Long categoryId) {
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Get products by category "+categoryId+" successfully!",
                productService.getProductsByCategory(categoryId),
                null,
                HttpStatus.OK
        ), HttpStatus.OK);
    }

    @GetMapping("/search")
    public ResponseEntity<ApiDataResponse<List<Product>>> getProductsByName(@RequestParam("keyword") String keyword) {
        return new ResponseEntity<>(new ApiDataResponse<>(
                true,
                "Get products by name "+keyword+" successfully!",
                productService.getProductsByName(keyword),
                null,
                HttpStatus.OK
        ), HttpStatus.OK);
    }
}
