package edu.service;

import edu.model.entity.Category;

import java.util.List;

public interface CategoryService {
    List<Category> getCategories();
    Category getCategoryById(Long id);
    Category insertCategory(Category category);
    Category updateCategory(Category category);
    void deleteCategoryById(Long id);
}
