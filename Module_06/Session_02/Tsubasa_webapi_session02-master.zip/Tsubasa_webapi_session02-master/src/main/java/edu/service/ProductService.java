package edu.service;

import edu.model.entity.Product;

import java.util.List;

public interface ProductService {
    List<Product> getProducts();
    Product insertProduct(Product product);
    Product updateProduct(Product product);
    void deleteProduct(Long id);
    List<Product> getProductsByCategory(Long cateId);
    List<Product> getProductsByName(String name);
}
