package edu.service.impl;

import edu.model.entity.Category;
import edu.repository.CategoryRepository;
import edu.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class CategoryServiceImpl implements CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public List<Category> getCategories() {
        return categoryRepository.findAll();
    }

    @Override
    public Category getCategoryById(Long id) {
        return categoryRepository.findById(id).orElseThrow(()->new NoSuchElementException("Khong ton tai category :"+id));
    }

    @Override
    public Category insertCategory(Category category) {
        return categoryRepository.save(category);
    }

    @Override
    public Category updateCategory(Category category) {
        categoryRepository.findById(category.getId()).orElseThrow(()->new NoSuchElementException("Khong ton tai category :"+category.getId()));
        return categoryRepository.save(category);
    }

    @Override
    public void deleteCategoryById(Long id) {
        categoryRepository.findById(id).orElseThrow(()->new NoSuchElementException("Khong ton tai category :"+id));
        categoryRepository.deleteById(id);
    }
}
