package edu.service.impl;

import edu.model.entity.Product;
import edu.repository.ProductRepository;
import edu.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepository productRepository;

    @Override
    public List<Product> getProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product insertProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public Product updateProduct(Product product) {
        productRepository.findById(product.getId()).orElseThrow(()-> new NoSuchElementException("Khong ton tai product "+product.getId()));
        return productRepository.save(product);
    }

    @Override
    public void deleteProduct(Long id) {
        productRepository.findById(id).orElseThrow(()-> new NoSuchElementException("Khong ton tai product "+id));
        productRepository.deleteById(id);
    }

    @Override
    public List<Product> getProductsByCategory(Long cateId) {
        return productRepository.findAllByCategory_Id(cateId);
    }

    @Override
    public List<Product> getProductsByName(String name) {
        return productRepository.findAllByNameContains(name);
    }
}
