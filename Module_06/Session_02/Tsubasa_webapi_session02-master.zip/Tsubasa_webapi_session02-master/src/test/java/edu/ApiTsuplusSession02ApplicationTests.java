package edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTsuplusSession02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
